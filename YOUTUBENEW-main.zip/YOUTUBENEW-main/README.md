目前每五個小時更新一次 

YouTube Data API v3 數量不足 

如果願意提供的 

請將YouTube Data API v3 KEY

寄送到md760323@gmail.com

目前徵求24組 讓他每小時能更新一次


如何申請YouTube Data API v3 KEY

https://ithelp.ithome.com.tw/articles/10224252

https://developers.google.com/youtube/v3/getting-started?hl=zh-tw
